// app.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Quiz = require('./quizModel');

const app = express();
const port = 3000;

// Connect to MongoDB
 
mongoose.set("strictQuery", false);
const url="mongodb://localhost:27017/quizApp"
const mongooseConnected=mongoose.connect(url);

// Middleware
app.use(bodyParser.json());

// POST endpoint to create a new quiz
app.post('/quiz', async (req, res) => {
  try {
    const quizData = req.body;
    const quiz = await Quiz.create(quizData);
    res.status(201).json(quiz);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET endpoint to fetch all quizzes
app.get('/quiz', async (req, res) => {
  try {
    const quizzes = await Quiz.find();
    res.json(quizzes);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
