import React, { useState } from 'react';
import './App.css';
import QuizForm from '../src/Components/QuizForm';
import Quiz from '../src/Components/Quiz';
import Results from '../src/Components/Results';
import {
  BrowserRouter as Router,
  Routes,
  Route
} from 'react-router-dom';
import Home from './Components/Home';
function App() {
  const [quizzes, setQuizzes] = useState([]);
  const [currentQuiz, setCurrentQuiz] = useState(null);
  const [showQuizForm, setShowQuizForm] = useState(false);
  const [showQuiz, setShowQuiz] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [totalQuestions, setTotalQuestions] = useState(0);
  

  // Function to add a new quiz to the list
  const addQuiz = (quiz) => {
    setQuizzes([...quizzes, quiz]);
    setShowQuizForm(false);
  };
  const handleAddQuiz=()=>{
    setShowQuizForm(true);
  }

  // Function to start a quiz
  const startQuiz = (quiz) => {
    setCurrentQuiz(quiz);
    setScore(0);
    setTotalQuestions(quiz.questions.length);
    setShowQuizForm(false);
    setShowQuiz(true);
  };

  // Function to handle quiz completion and show results
  const handleQuizComplete = (score) => {
    setScore(score);
    setShowQuiz(false);
    setShowResults(true);
  };

  // Function to reset the quiz and show quiz form
  const resetQuiz = () => {
    setCurrentQuiz(null);
    setShowQuizForm(true);
    setShowQuiz(false);
    setShowResults(false);
  };
  return (
    <div className="App">
      <header className="App-header">
        <h1>Quiz Platform </h1>
        <button className='AddQuiz' onClick={handleAddQuiz}>Create New Quiz</button>
      </header>
      {showQuizForm && <QuizForm addQuiz={addQuiz} />}
      <Router>
        <div>
          
          <Routes>
            <Route exact path="/" element={<Home/>}></Route>
            
            {/* {showQuizForm && <QuizForm addQuiz={addQuiz} />}
            {showQuiz && <Quiz quiz={currentQuiz} onComplete={handleQuizComplete} />}
            {showResults && <Results score={score} totalQuestions={totalQuestions} onReset={resetQuiz} />} */}
            </Routes>
            </div>
            </Router>
        </div>
        );
}

        export default App;
