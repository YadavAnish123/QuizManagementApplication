import React from 'react'

const Home=()=> {
  return (
     <div>
         <h1>No active Quiz</h1>
     </div>
  )
}

export default Home