import React, { useState } from 'react';
//import './QuizForm.css';

const QuizForm = ({ addQuiz }) => {
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", "", "", ""]);
  const [correctAnswer, setCorrectAnswer] = useState("");
  
  const handleSubmit = (e) => {
    e.preventDefault();
    const quiz = {
      question: question,
      options: options.filter(option => option.trim() !== ""),
      correctAnswer: correctAnswer
    };
    addQuiz(quiz);
    setQuestion("");
    setOptions(["", "", "", ""]);
    setCorrectAnswer("");
  };

  const handleOptionChange = (e, index) => {
    const updatedOptions = [...options];
    updatedOptions[index] = e.target.value;
    setOptions(updatedOptions);
  };

  return (
    <div className="quiz-form">
      <h2>Create Quiz</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="question">Question:</label>
        <input
          type="text"
          id="question"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          required
        />

        {[0, 1, 2, 3].map(index => (
          <div key={index} className="option">
            <label htmlFor={`option${index}`}>Option {index + 1}:</label>
            <input
              type="text"
              id={`option${index}`}
              value={options[index]}
              onChange={(e) => handleOptionChange(e, index)}
              required
            />
          </div>
        ))}

        <label htmlFor="correctAnswer">Correct Answer:</label>
        <select
          id="correctAnswer"
          value={correctAnswer}
          onChange={(e) => setCorrectAnswer(e.target.value)}
          required
        >
          <option value="">Select correct answer</option>
          {options.map((option, index) => (
            <option key={index} value={option}>{option}</option>
          ))}
        </select>

        <button type="submit">Add Question</button>
      </form>
    </div>
  );
};

export default QuizForm;
