import React, { useState } from 'react';
import './Quiz.css';

const Quiz = ({ quiz, onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState("");
  const [showNextButton, setShowNextButton] = useState(false);

  const handleOptionSelect = (e) => {
    setSelectedOption(e.target.value);
    setShowNextButton(true);
  };

  const handleNextQuestion = () => {
    if (selectedOption === quiz.questions[currentQuestion].correctAnswer) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption("");
      setShowNextButton(false);
    }
  };

  const finishQuiz = () => {
    const score = Math.round((currentQuestion / quiz.questions.length) * 100);
    onComplete(score);
  };

  return (
    <div className="quiz">
      <h2>{quiz.name}</h2>
      <p>Question {currentQuestion + 1} of {quiz.questions.length}</p>
      <p>{quiz.questions[currentQuestion].question}</p>
      <form>
        {quiz.questions[currentQuestion].options.map((option, index) => (
          <div key={index} className="option">
            <input
              type="radio"
              id={`option${index}`}
              name="option"
              value={option}
              checked={selectedOption === option}
              onChange={handleOptionSelect}
            />
            <label htmlFor={`option${index}`}>{option}</label>
          </div>
        ))}
      </form>
      {showNextButton && (
        <button onClick={currentQuestion === quiz.questions.length - 1 ? finishQuiz : handleNextQuestion}>
          {currentQuestion === quiz.questions.length - 1 ? 'Finish' : 'Next Question'}
        </button>
      )}
    </div>
  );
};

export default Quiz;
