import React from 'react';
//import './Results.css';

const Results = ({ score, totalQuestions, onReset }) => {
  return (
    <div className="results">
      <h2>Quiz Results</h2>
      <p>You scored {score} out of {totalQuestions}!</p>
      <button onClick={onReset}>Take Another Quiz</button>
    </div>
  );
};

export default Results;
